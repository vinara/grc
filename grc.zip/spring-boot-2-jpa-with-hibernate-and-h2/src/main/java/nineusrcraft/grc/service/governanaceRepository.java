package nineusrcraft.grc.service;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface governanaceRepository extends JpaRepository<frameworktable, Long> {


    @Query("select c from frameworktable c where c.Id=:Id")
    Optional<frameworktable> FindResult(@Param("Id") final Integer Id);

    @Modifying
    @Query("delete from frameworktable c where c.Id=:Id")
    void deleteById(@Param("Id") final Integer Id);
}
