package nineusrcraft.grc.service;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@NoArgsConstructor
@Table(name = "framework_table", schema = "public")
public class frameworktable {
    @Id
    @Column(name = "id", columnDefinition = "integer")
    private Integer Id;
    @Column(name = "frameworkname", columnDefinition = "varchar(1000) default ''")
    private String framework_Name;
    @Column(name = "frameworkdetails", columnDefinition = "varchar(1020) default ''")
    private String framework_Details;

    @Column(name = "parentframeworkid", columnDefinition = "integer")
    private Long framework_Parent;

    @Column(name = "status", columnDefinition = "TEXT default ''")
    private String framework_Status;
}
