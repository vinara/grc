package nineusrcraft.grc.service;

import io.swagger.annotations.ApiOperation;
import java.net.URI;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.EntityModel;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

@RestController
public class governanceResource {

    @Autowired
    private governanaceRepository governanaceRepository;

    @GetMapping("/governance")
    public List<frameworktable> retrieveAllStudents() {

        List<frameworktable> detailsList = governanaceRepository.findAll();
        return detailsList;
    }

    @GetMapping("/governance/{id}")
    @ApiOperation(value = "Find framework by id",
              notes = "Also returns a link to retrieve all framework with rel - all-framework")
    public EntityModel<frameworktable> retrieveGovernanceDetails(@PathVariable Integer id) throws Exception {
        Optional<frameworktable> detailsOptional = governanaceRepository.FindResult(id);


        if (!detailsOptional.isPresent())
            throw new Exception("id-" + id);

        EntityModel<frameworktable> resource = EntityModel.of(new frameworktable());
        return resource;
    }

    @Transactional
    @DeleteMapping("/governanceDelete/{id}")
    public void deleteframeworkById(@PathVariable Integer id) {
        governanaceRepository.deleteById(id);
    }

    @PostMapping("/governanceDetails")
    public ResponseEntity<Object> createFramework(@RequestBody frameworktable details) {
        frameworktable savedFramework = governanaceRepository.save(details);

        URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}")
                  .buildAndExpand(savedFramework.getFramework_Details()).toUri();

        return ResponseEntity.created(location).build();

    }

    @PutMapping("/governance/{id}")
    public ResponseEntity<Object> updategovernanaceDetails(@RequestBody frameworktable details, @PathVariable Integer id) {

        Optional<frameworktable> frameworkdetailsOptional = governanaceRepository.FindResult(id);

        if (!frameworkdetailsOptional.isPresent())
            return ResponseEntity.notFound().build();

        frameworkdetailsOptional.get().setFramework_Details(details.getFramework_Details());

        governanaceRepository.save(frameworkdetailsOptional.get());

        return ResponseEntity.noContent().build();
    }
}
